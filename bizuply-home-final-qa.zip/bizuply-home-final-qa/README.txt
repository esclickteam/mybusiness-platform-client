Bizuply homepage final QA package (PR #1007)
============================================

01-first-load-desktop-unedited.mp4  Cold first load desktop EN (no edit)
02-first-load-mobile-unedited.mp4   Cold first load mobile EN (no edit)
03-guest-ready-desktop.png          Guest home ready EN desktop
04-hero-mid-scroll.png              Hero mid-scroll — product still visible
05-guest-ready-mobile.png           Guest home ready EN mobile
06-guest-ready-he-desktop.png       Guest home ready HE desktop
07-guest-ready-he-mobile.png        Guest home ready HE mobile
08-loggedin-boot-hold.png           Logged-in / boot hold (blank, no Loading, no home)
09-loggedin-after-redirect.png      After redirect off marketing home
10-hero-progress-037.png            Hero crossfade ~37%
11-hero-progress-070.png            Hero crossfade ~70%
12/13-*-full-scroll.mp4             Optional full-page scroll recordings (if included)

No Merge / Deploy — review only.
