PR #1007 verification package
Commit: 7232b732cfae7fde39bc16dcb19c797621b78ab9
Preview: http://127.0.0.1:3000 (local Vite on feat/home-media-faq tip)

Guest cold-load / hard-refresh / Slow 4G EN+HE desktop+mobile:
  - no Bizuply Loading splash
  - Skip to content not visible (clip until :focus-visible)
  - hero product present

Logged-in:
  01-loggedin-home-to-full-dashboard.mp4 — / → full dashboard with nav+content
  screenshots for /he, hard refresh, home→login→dashboard, direct dashboard
